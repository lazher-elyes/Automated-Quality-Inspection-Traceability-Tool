import os
import pandas as pd

# Configuration
SN_LIST_FILE = "sn_list.txt"
NG_PRODUCTS_FILE = "ng_products.xlsx"
PRODUCT_REFERENCE = "VPLR1F-18B955-AA"

# Load valid SNs
def load_sn_list(filename=SN_LIST_FILE):
    if not os.path.exists(filename):
        print(f"❌ Error: {filename} not found.")
        return set()
    with open(filename, "r") as file:
        return set(line.strip() for line in file)

# Load existing NG products
def load_ng_products(filename=NG_PRODUCTS_FILE):
    if os.path.exists(filename):
        try:
            df = pd.read_excel(filename)
            return dict(zip(df["SN"], df["Mesure"]))
        except Exception as e:
            print(f"⚠️ Error loading {filename}: {e}")
            return {}
    return {}

# Save NG products to Excel immediately
def save_ng_products(ng_products, filename=NG_PRODUCTS_FILE):
    df = pd.DataFrame(ng_products.items(), columns=["SN", "Mesure"])
    df.to_excel(filename, index=False)

# Extract SN from scan string
def extract_sn_from_scan(scan):
    parts = scan.strip().split("|")
    if len(parts) < 2:
        return None, "❌ Invalid scan format."
    if PRODUCT_REFERENCE not in scan:
        return None, "❌ Product reference not found in scan."
    return parts[1], None  # Extracted SN

def main():
    # Config options
    validate_input = input("🔍 Validate SNs against list? (yes/no): ").strip().lower()
    validate_against_list = (validate_input == "yes")

    # Load SN list
    sn_list = load_sn_list() if validate_against_list else set()
    if validate_against_list and not sn_list:
        print("⚠️ SN list is empty or missing. Exiting.")
        return

    # Load NG products from the previous session
    ng_products = load_ng_products()

    # Ask user if they want to input measurements
    ask_measurement_input = input("📏 Ask for measurement for each SN? (yes/no): ").strip().lower()
    ask_measurement = (ask_measurement_input == "yes")

    print("\n💡 Scan product label (type 'exit' to quit):")
    
    # Counter for processed pieces
    processed_counter = 0

    try:
        while True:
            scan = input("\n📷 Scan: ").strip()
            if scan.lower() == "exit":
                break

            sn, error = extract_sn_from_scan(scan)
            if error:
                print(error)
                continue

            if validate_against_list and sn not in sn_list:
                print("❌ SN not found in list.")
                continue

            if sn in ng_products:
                print("⚠️ SN already recorded.")
                continue

            # If measurement is required
            while True:
                if ask_measurement:
                    measurement = input(f"📏 Enter required measurement for {sn}: ").strip()
                    if measurement:  # Check if measurement is not empty
                        break
                    print("❗ Measurement is required.")
                else:
                    measurement = ""  # Automatically skip if not required
                    break

            # Save SN and measurement
            ng_products[sn] = measurement
            try:
                save_ng_products(ng_products)
                processed_counter += 1  # Increment counter after successful validation
                print(f"✅ SN {sn} validated and saved. Total validated pieces: {processed_counter}")
            except Exception as e:
                print(f"❌ Failed to save: {e}")
                # Optionally: remove sn from ng_products if save fails
                del ng_products[sn]

    except KeyboardInterrupt:
        print("\n🔴 Program interrupted by user. Exiting gracefully...")
        return  # Gracefully exit the program

if __name__ == "__main__":
    main()
