import pandas as pd

# Load data
file1 = pd.read_excel("file1.xlsx")
file2 = pd.read_excel("file2.xlsx")

# Normalize column names (if needed)
file1.columns = ["Box No", "SN"]
file2.columns = ["SN"]

# Merge to get Box No. for selected SNs
matched = pd.merge(file2, file1, on="SN", how="left")

# Get all related boxes from selected SNs
boxes_of_interest = matched["Box No"].dropna().unique()

# For each relevant box, get all SNs
related_sn = file1[file1["Box No"].isin(boxes_of_interest)].copy()

# Mark whether SN is in selected list
related_sn["From_Selected_File"] = related_sn["SN"].isin(file2["SN"]).map({True: "YES", False: "NO"})

# Save to Excel
related_sn.to_excel("Box_Mapping_with_Selected.xlsx", index=False)
