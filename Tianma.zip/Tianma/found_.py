# compare_sns.py

def load_sns_from_file(filename):
    with open(filename, 'r') as f:
        return set(line.strip() for line in f if line.strip())

def main():
    scanned_file = 'scanned_sns_backup.txt'
    target_file = 'target_sns.txt'
    output_file = 'found.txt'

    scanned_sns = load_sns_from_file(scanned_file)
    target_sns = load_sns_from_file(target_file)

    found_sns = scanned_sns.intersection(target_sns)
    found_count = len(found_sns)

    with open(output_file, 'w') as f:
        f.write(f"Number of SNs found: {found_count}\n")
        f.write("Found SNs:\n")
        for sn in sorted(found_sns):
            f.write(f"{sn}\n")

    print(f"Results written to {output_file}.")

if __name__ == "__main__":
    main()
