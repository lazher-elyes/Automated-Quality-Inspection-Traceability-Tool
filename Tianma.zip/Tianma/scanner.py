import openpyxl
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
from datetime import datetime
import os
import platform
import pyttsx3
from PIL import Image

# Setup TTS engine
engine = pyttsx3.init()
def speak(text):
    engine.say(text)
    engine.runAndWait()

def image_to_ascii(path, width=80):
    chars = "@%#*+=-:. "
    img = Image.open(path)
    img = img.convert("L")
    w, h = img.size
    ratio = h / w
    new_height = int(width * ratio * 0.55)
    img = img.resize((width, new_height))

    pixels = img.getdata()
    scale = 256 // len(chars)

    ascii_str = ""
    for i, pixel in enumerate(pixels):
        index = min(pixel // scale, len(chars) - 1)
        c = chars[index]
        if c == '.':
            c = f"\033[91m{c}\033[0m"  # red
        ascii_str += c
        if (i + 1) % width == 0:
            ascii_str += "\n"

    print(ascii_str)

def load_target_sns(filename):
    with open(filename, 'r') as file:
        return set(line.strip() for line in file if line.strip())

def load_backup_sns(backup_file):
    if not os.path.exists(backup_file):
        return set()
    with open(backup_file, 'r') as f:
        return set(line.strip().split(',')[0] for line in f if line.strip())

def append_sn_to_excel(excel_file, sn, timestamp, is_target=False):
    if os.path.exists(excel_file):
        wb = load_workbook(excel_file)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.append(["SN", "Timestamp"])  # header

    row = [sn, timestamp]
    ws.append(row)

    if is_target:
        green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        for cell in ws[ws.max_row]:
            cell.fill = green_fill

    wb.save(excel_file)

def log_sn_to_txt(log_file, sn, timestamp):
    with open(log_file, 'a') as f:
        f.write(f"{sn},{timestamp}\n")

def log_target_found(sn, timestamp, file="target_found.txt"):
    with open(file, 'a') as f:
        f.write(f"{sn},{timestamp}\n")

def open_excel_file(file_path):
    if platform.system() == 'Windows':
        os.startfile(file_path)
    elif platform.system() == 'Darwin':
        os.system(f"open '{file_path}'")
    else:
        os.system(f"xdg-open '{file_path}'")

def main():
    PREFIX = "VPJPLF-18B955"
    TARGET_LIST = "target_sns.txt"
    SCAN_FOLDER = "scans"
    LOG_FILE = "scanned_sns_backup.txt"
    TARGET_FOUND_FILE = "target_found.txt"
    ERROR_IMAGE_PATH = "erreur.jpg"

    os.makedirs(SCAN_FOLDER, exist_ok=True)

    target_sns = load_target_sns(TARGET_LIST)
    all_previous_sns = load_backup_sns(LOG_FILE)

    target_sn_counter = 0

    print("=" * 50)
    print("🔧 Serial Number Scanner System")
    print("🔖 Developed by: Mohamed Elyes")
    print("📅", datetime.now().strftime("%Y-%m-%d"))
    print(f"🧾 Already scanned total: {len(all_previous_sns)}")
    print("=" * 50)

    try:
        while True:
            scanned_input = input("📥 Scan: ").strip()

            if not scanned_input.startswith(PREFIX):
                print(f"❌ Invalid scan: must start with '{PREFIX}'. Try again.")
                speak("Invalid scan")
                continue

            if len(scanned_input) < 28:
                print("⚠️ Input too short. Expected at least 28 characters.")
                speak("Input too short")
                continue

            sn_candidate = scanned_input[16:28]

            if len(sn_candidate) != 12:
                print(f"⚠️ SN '{sn_candidate}' is not 12 characters. Try again.")
                speak("Serial number incorrect")
                continue

            if sn_candidate in all_previous_sns:
                print(f"🔁 SN {sn_candidate} already exists in backup. Skipped.")
                speak("Already scanned")
                continue

            is_target = sn_candidate in target_sns
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            current_day = datetime.now().strftime("%Y-%m-%d")
            EXCEL_FILE = os.path.join(SCAN_FOLDER, f"scanned_{current_day}.xlsx")

            append_sn_to_excel(EXCEL_FILE, sn_candidate, timestamp, is_target=is_target)
            log_sn_to_txt(LOG_FILE, sn_candidate, timestamp)
            all_previous_sns.add(sn_candidate)

            if is_target:
                target_sn_counter += 1
                log_target_found(sn_candidate, timestamp, TARGET_FOUND_FILE)
                print(f"🎯 ✅ FOUND: SN {sn_candidate} HOTOU ALE JNAB and saved!")
                image_to_ascii(ERROR_IMAGE_PATH)
                speak("HABES GHADI HOTOU ALE JNAB HOTOU ALE JNAB DIRDIRDIRDIRDIRDIRDIRDIR HOTOU ALE JNAB ")
            else:
                print(f"✅ SN {sn_candidate} saved successfully.")
                speak("saved successfully")

            print(f"📊 Total unique SNs scanned so far: {len(all_previous_sns)}")
            print(f"🎯 Total TARGET SNs found: {target_sn_counter}\n")

    except KeyboardInterrupt:
        print(f"\n🔖 Developed by: Mohamed Elyes")
        print(f"\n🛑 Scanning stopped. Final count today: {len(all_previous_sns)}")
        speak("Scanning stopped")
        open_excel_file(EXCEL_FILE)

if __name__ == "__main__":
    main()
