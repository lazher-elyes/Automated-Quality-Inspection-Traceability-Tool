import os
import platform
import pyttsx3
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill

# Configuration
PRODUCT_REFERENCE = "VPLR1F-18B955-AA"
INVOICE_SN_FILE = "INV_sn.txt"
BACKUP_FILE = "sorting_backup.txt"
REPORT_FOLDER = "scans"
NG_LIGHT_TEXT = "NG LIGHT UP"

# Setup TTS
engine = pyttsx3.init()
def speak(text):
    try:
        engine.say(text)
        engine.runAndWait()
    except RuntimeError:
        pass  # Avoid crash if TTS is still running

# Load SNs from invoice file
def load_invoice_sns(filename):
    if not os.path.exists(filename):
        return set()
    with open(filename, "r") as file:
        return set(line.strip() for line in file if line.strip())

# Load previously scanned SNs from backup
def load_backup_sns(filename):
    if not os.path.exists(filename):
        return set()
    with open(filename, "r") as file:
        return set(line.strip().split(',')[0] for line in file if line.strip())

# Append to Excel report
def append_to_excel(excel_file, sn, timestamp, measurement, status, operator_name):
    if os.path.exists(excel_file):
        wb = load_workbook(excel_file)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.append(["SN", "Timestamp", "Measurement", "Status", "Operator"])

    row = [sn, timestamp, measurement, status, operator_name]
    ws.append(row)

    if status == "NG":
        red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        for cell in ws[ws.max_row]:
            cell.fill = red_fill

    wb.save(excel_file)

# Log to text backup
def log_to_backup(sn, timestamp, measurement):
    with open(BACKUP_FILE, "a") as file:
        file.write(f"{sn},{timestamp},{measurement}\n")

# Auto open Excel on exit
def open_excel_file(file_path):
    if platform.system() == 'Windows':
        os.startfile(file_path)
    elif platform.system() == 'Darwin':
        os.system(f"open '{file_path}'")
    else:
        os.system(f"xdg-open '{file_path}'")

def evaluate_measurement(measurement):
    if measurement.upper() == "NG LIGHT UP":
        return "NG"
    try:
        value = float(measurement)
        if value == 0 or value > 4:
            return "NG"
        elif 0 < value <= 4:
            return "GOOD"
        else:
            return "INVALID"
    except ValueError:
        if measurement.upper() in ["0.L", "N.L"]:
            return "NG"
        return "INVALID"

def main():
    os.makedirs(REPORT_FOLDER, exist_ok=True)
    invoice_sns = load_invoice_sns(INVOICE_SN_FILE)
    scanned_sns = load_backup_sns(BACKUP_FILE)
    ng_list = []


    current_date = datetime.now().strftime("%Y-%m-%d")
    excel_file = os.path.join(REPORT_FOLDER, f"sorting report_{current_date}.xlsx")

    print("© 2025 Mohamed Elyes Lazher – All rights reserved.")
    print("🔖 Developed by: Mohamed Elyes")
    print("📦 Sorting System")
    print(f"📅 Session Date: {current_date}")
    print(f"✅ Loaded {len(invoice_sns)} SNs from invoice list.")
    print(f"🧾 Already sorted: {len(scanned_sns)}")
    print("=" * 50)
    operator_name = input("👷 Enter operator name: ").strip()

    # Counters for the session
    scanned_count = 0
    good_count = 0
    ng_count = 0

    try:
        while True:
            scan_input = input("📥 Scan SN: ").strip()
            if scan_input.lower() == "exit":
                break

            parts = scan_input.split("|")
            if len(parts) < 2 or PRODUCT_REFERENCE not in scan_input:
                print("❌ Invalid scan format or missing product reference.")
                speak("Invalid scan")
                continue

            sn = parts[1]

            if sn in scanned_sns:
                print(f"🔁 SN {sn} already scanned.")
                speak("Already scanned")
                continue

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if sn not in invoice_sns:
                print("🚫 That piece does NOT belong to the current INVOICE.")
                speak("Wrong piece")
                continue

            # Ask for measurement
            while True:
                measurement = input(f"📏 Enter measurement for {sn}: 🔴NG (0.L,N.L,>4)/✅Good(0<X<=4)").strip()
                status = evaluate_measurement(measurement)
                if status == "INVALID":
                    print("❌ Invalid measurement input. Try again.")
                    speak("Invalid measurement")
                else:
                    break

            # Save
            append_to_excel(excel_file, sn, timestamp, measurement, status, operator_name)
            log_to_backup(sn, timestamp, measurement)
            scanned_sns.add(sn)

            scanned_count += 1
            if status == "NG":
                ng_count += 1
                ng_list.append((sn, measurement, timestamp))
                print(f"🔴 No GOOD piece recorded: {sn}")
                speak("No GOOD piece")
            else:
                good_count += 1
                print(f"✅ GOOD piece recorded: {sn}")
                speak("Good piece")

            print(f"📊 Scanned: {scanned_count} | ✅ GOOD: {good_count} | ❌ NG: {ng_count}")

    except KeyboardInterrupt:
        print("\n🛑 Scanning interrupted by user.")

    print("\n📋 Session Summary Report:")

    total_sns_scanned = 0
    total_ng_pieces = 0
    ng_entries = []

    if os.path.exists(BACKUP_FILE):
        with open(BACKUP_FILE, "r") as file:
            for line in file:
                total_sns_scanned += 1
                _, _, measure = line.strip().split(",", 2)
                if evaluate_measurement(measure) == "NG":
                    total_ng_pieces += 1
                    parts = line.strip().split(",")
                    if len(parts) == 3:
                        ng_entries.append(parts)

    print(f"📦 Total Sorted: {total_sns_scanned}")
    print(f"❗ Total NG pieces: {total_ng_pieces}")

    speak("Session finished")
    open_excel_file(excel_file)

if __name__ == "__main__":
    main()
