import pandas as pd

# --- File Paths ---
file1 = 'boxes_data.xlsx'   # Excel file with Box No and SN
file2 = 'box_list.txt'      # Text file with Box Nos

# --- Step 1: Read Excel File 1 ---
df = pd.read_excel(file1)
df.columns = df.columns.str.strip()  # Clean column names
df['Box No'] = df['Box No'].astype(str).str.strip()  # Normalize box numbers

# --- Step 2: Read box numbers from File 2 ---
with open(file2, 'r') as f:
    box_list = {line.strip() for line in f if line.strip()}

# --- Step 3: Filter rows where Box No is in the list ---
filtered_df = df[df['Box No'].isin(box_list)]

# --- Step 4: Save the result to Excel ---
output_file = 'filtered_sns.xlsx'
filtered_df.to_excel(output_file, index=False)

# --- Confirmation ---
print(f"✅ {len(filtered_df)} SNs found and saved to '{output_file}'.")

