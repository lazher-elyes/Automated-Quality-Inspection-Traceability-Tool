# Read SNs from A.txt
with open('A.txt', 'r') as file_a:
    A = [line.strip() for line in file_a if line.strip()]

# Read SNs from B.txt
with open('B.txt', 'r') as file_b:
    B = [line.strip() for line in file_b if line.strip()]

# Find SNs present in B but missing in A
missing_in_A = sorted(set(B) - set(A))

# Print results
print("SNs present in B but missing in A:")
for sn in missing_in_A:
    print(sn)

# Optionally, save to a new file
with open('missing_in_A.txt', 'w') as output_file:
    for sn in missing_in_A:
        output_file.write(sn + '\n')
